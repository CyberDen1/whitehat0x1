$domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
$DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
$Users = Get-ADUser -SearchBase $DistinguishedName -filter {Enabled -eq $True -and PasswordNeverExpires -eq $False} -Properties msDS-UserPasswordExpiryTimeComputed, PasswordLastSet, CannotChangePassword
$Users | select Name, @{Name="ExpirationDate";Expression= {[datetime]::FromFileTime($_."msDS-UserPasswordExpiryTimeComputed")}}, PasswordLastSet | Out-File ExpirationDate.txt