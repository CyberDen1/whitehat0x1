﻿$60Days = (get-date).adddays(-60)
$filter = {
  (lastlogondate -notlike "*" -OR lastlogondate -le $60days) -AND
  (passwordlastset -le $60days) -AND
  (enabled -eq $True) -AND
  (whencreated -le $60days)
}
Get-ADUser -properties * `
 -filter $filter `
 | select-object `
    name, `
    SAMaccountname, `
    passwordExpired, `
    PasswordNeverExpires, `
    logoncount, `
    whenCreated, `
    lastlogondate, `
    PasswordLastSet, `
    lastlogontimestamp, `
    CanonicalName `
 | Out-GridView