﻿$15Days = (get-date).adddays(-15)
$filter = {
  (lastlogondate -notlike "*" -OR lastlogondate -le $15days) -AND
  (passwordlastset -le $15days) -AND
  (enabled -eq $True) -AND
  (whencreated -le $15days)
}
Get-ADUser -properties * `
 -filter $filter `
 | select-object `
    name, `
    SAMaccountname, `
    passwordExpired, `
    PasswordNeverExpires, `
    logoncount, `
    whenCreated, `
    lastlogondate, `
    PasswordLastSet, `
    lastlogontimestamp, `
    CanonicalName `
 | Out-GridView