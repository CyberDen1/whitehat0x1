﻿$30Days = (get-date).adddays(-30)
$filter = {
  (lastlogondate -notlike "*" -OR lastlogondate -le $30days) -AND
  (passwordlastset -le $30days) -AND
  (enabled -eq $True) -AND
  (whencreated -le $30days)
}
Get-ADUser -properties * `
 -filter $filter `
 | select-object `
    name, `
    SAMaccountname, `
    passwordExpired, `
    PasswordNeverExpires, `
    logoncount, `
    whenCreated, `
    lastlogondate, `
    PasswordLastSet, `
    lastlogontimestamp, `
    CanonicalName `
 | Out-GridView