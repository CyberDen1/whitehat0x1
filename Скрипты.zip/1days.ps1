﻿$1Days = (get-date).adddays(-1)
$filter = {
  (lastlogondate -notlike "*" -OR lastlogondate -le $1days) -AND
  (passwordlastset -le $1days) -AND
  (enabled -eq $True) -AND
  (whencreated -le $1days)
}
Get-ADUser -properties * `
 -filter $filter `
 | select-object `
    name, `
    SAMaccountname, `
    passwordExpired, `
    PasswordNeverExpires, `
    logoncount, `
    whenCreated, `
    lastlogondate, `
    PasswordLastSet, `
    lastlogontimestamp, `
    CanonicalName `
 | Out-GridView