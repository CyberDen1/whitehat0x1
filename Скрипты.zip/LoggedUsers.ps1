Import-Module .\PowerView.ps1
Get-NetLoggedon | Out-File LoggedUsers.txt