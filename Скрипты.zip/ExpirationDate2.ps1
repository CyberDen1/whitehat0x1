$domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
$DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
$Users = Get-ADUser -SearchBase $DistinguishedName -filter {Enabled -eq $True -and PasswordNeverExpires -eq $False} -Properties msDS-UserPasswordExpiryTimeComputed, PasswordLastSet, CannotChangePassword | Out-File ExpirationDate2.txt
foreach($user in $Users){
if( [datetime]::FromFileTime($user."msDS-UserPasswordExpiryTimeComputed") -lt (Get-Date)) {
$user.Name
}
}