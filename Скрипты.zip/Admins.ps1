﻿$GruppeMedlemmer = @()
$Groups = Get-ADGroup `
 -Filter {(name -like "*админ*") -or (name -like "*admin*")} `
 -properties *
 
foreach ($g in $Groups) {
$members = $g | Get-ADGroupMember -recursive
     foreach ($m in $members) {
       $Info = New-Object psObject
       $Info | add-member -MemberType NoteProperty `
        -Name "GroupName" -Value $g.Name
       $Info | add-member -MemberType NoteProperty `
        -Name "Description" -Value ($g.description | out-string)
       $Info | add-member -MemberType NoteProperty `
        -Name "MemberOf" -Value ($g.MemberOf | out-string)
       $Info | Add-Member -MemberType NoteProperty `
        -Name "Member" -Value $m.name
       $Info | Add-Member -MemberType NoteProperty `
        -Name "SamAccountName" -Value $m.SamAccountName
       $Info | Add-Member -MemberType NoteProperty `
        -Name "distinguishedName" -Value $m.distinguishedName
       $Info | Add-Member -MemberType NoteProperty `
        -Name "objectClass" -Value $m.objectClass
       $GruppeMedlemmer+= $Info
     }
  }
$GruppeMedlemmer | Sort-Object GroupName | Out-GridView