﻿get-aduser -filter * -Properties * `
 | where-object { `
  ($_.userAccountControl -ne 512) -and `
  ($_.useraccountcontrol -ne 66048) -and `
  ($_.useraccountcontrol -ne 514) -and `
  ($_.useraccountcontrol -ne 66050) -and `
  ($_.useraccountcontrol -ne 590336) -and `
  ($_.useraccountcontrol -ne 4260352) -and `
  ($_.useraccountcontrol -ne 2163202) -and `
  ($_.useraccountcontrol -ne 590338)} `
 | Select-Object `
  name, `
  samaccountname, `
  enabled, `
  Canonicalname, `
  whenCreated, `
  lastlogondate,`
  userAccountControl `
 | Out-GridView
