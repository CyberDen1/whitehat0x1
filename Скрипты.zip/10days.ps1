﻿$10Days = (get-date).adddays(-10)
$filter = {
  (lastlogondate -notlike "*" -OR lastlogondate -le $10days) -AND
  (passwordlastset -le $10days) -AND
  (enabled -eq $True) -AND
  (whencreated -le $10days)
}
Get-ADUser -properties * `
 -filter $filter `
 | select-object `
    name, `
    SAMaccountname, `
    passwordExpired, `
    PasswordNeverExpires, `
    logoncount, `
    whenCreated, `
    lastlogondate, `
    PasswordLastSet, `
    lastlogontimestamp, `
    CanonicalName `
 | Out-GridView