Get-ADUser -filter * -Properties "LastLogonDate" | select name, LastLogonDate | Out-GridView
